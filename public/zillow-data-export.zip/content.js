(function() {
    let properties = new Map();
    let totalResultCount = 0;
    let vaultUrl = "";

    // Inject the main world script
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('inject.js');
    (document.head || document.documentElement).appendChild(script);

    // Create the Floating Dock container
    const dock = document.createElement('div');
    dock.className = 'zillow-export-dock';

    // Create the Sync Status badge button
    const syncBadge = document.createElement('button');
    syncBadge.className = 'zillow-sync-badge';
    syncBadge.innerHTML = `
        <span class="sync-dot offline"></span>
        <span class="sync-text">🔴 Setup Vault</span>
    `;

    // Create the Scan All Pages button
    const scanBtn = document.createElement('button');
    scanBtn.className = 'zillow-export-btn';
    scanBtn.style.background = '#052251';
    scanBtn.style.display = 'none';
    scanBtn.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="22" y1="12" x2="18" y2="12"></line><line x1="6" y1="12" x2="2" y2="12"></line><line x1="12" y1="6" x2="12" y2="2"></line><line x1="12" y1="22" x2="12" y2="18"></line></svg>
        <span>Scan All Pages</span>
    `;

    // Create the Export CSV/Sheets button
    const exportBtn = document.createElement('button');
    exportBtn.className = 'zillow-export-btn';
    exportBtn.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
        <span>Export CSV</span>
        <span class="zillow-export-count">0</span>
    `;

    // Assemble the dock
    dock.appendChild(syncBadge);
    dock.appendChild(scanBtn);
    dock.appendChild(exportBtn);

    function appendDock() {
        if (document.body) {
            document.body.appendChild(dock);
        } else {
            const observer = new MutationObserver(() => {
                if (document.body) {
                    document.body.appendChild(dock);
                    observer.disconnect();
                }
            });
            observer.observe(document.documentElement, { childList: true });
        }
    }
    appendDock();

    const countBadge = exportBtn.querySelector('.zillow-export-count');
    const syncDot = syncBadge.querySelector('.sync-dot');
    const syncText = syncBadge.querySelector('.sync-text');

    function updateScanVisibility() {
        if (totalResultCount > properties.size) {
            scanBtn.style.display = 'flex';
        } else {
            scanBtn.style.display = 'none';
        }
    }

    // Load saved Vault API URL and update status UI
    function loadVaultUrl() {
        chrome.storage.local.get(['vaultUrl'], async (result) => {
            if (result.vaultUrl) {
                vaultUrl = result.vaultUrl;
                updateSyncUI('syncing', '🟡 Testing Vault...');
                try {
                    const response = await fetch(`${vaultUrl}/api/listings`, { method: "GET" });
                    if (response.ok) {
                        updateSyncUI('online', '🟢 Vault Active');
                    } else {
                        updateSyncUI('offline', `🔴 Database Offline (${response.status})`);
                    }
                } catch (err) {
                    console.error("[Zillow Export] Startup connection test error:", err);
                    updateSyncUI('offline', '🔴 Connection Error');
                }
            } else {
                vaultUrl = "";
                updateSyncUI('offline', '🔴 Setup Vault');
            }
        });
    }
    loadVaultUrl();

    // Helper to change Sync Status UI state
    function updateSyncUI(state, text) {
        syncDot.className = 'sync-dot ' + state;
        syncText.textContent = text;
    }

    // Auto-sync function to POST new properties to backend D1 database
    async function autoSyncProperties(newProps) {
        if (!vaultUrl) {
            console.log("[Zillow Export] Auto-Sync skipped: Vault URL not configured.");
            return;
        }

        updateSyncUI('syncing', `🟡 Syncing ${newProps.length}...`);
        
        try {
            const response = await fetch(`${vaultUrl}/api/listings`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ properties: newProps })
            });

            if (response.ok) {
                const resData = await response.json();
                updateSyncUI('online', `🟢 Synced +${newProps.length}`);
                if (window.location.search.includes('autoSync=true') || window.location.hash.includes('autoSync=true')) {
                    setTimeout(() => {
                        window.close();
                    }, 800);
                }
                setTimeout(() => {
                    updateSyncUI('online', '🟢 Vault Active');
                }, 2500);
            } else {
                console.error("[Zillow Export] Auto-sync server error:", response.status);
                updateSyncUI('offline', '🔴 Sync Failed (500)');
            }
        } catch (err) {
            console.error("[Zillow Export] Auto-sync network error:", err);
            updateSyncUI('offline', '🔴 Connection Error');
        }
    }

    // Listen for events from the injected script
    window.addEventListener('zillow-data-event', (event) => {
        const { type, data } = event.detail;
        if (type === 'ZILLOW_DATA_FOUND') {
            const newlyDiscovered = [];
            data.properties.forEach(prop => {
                if (!properties.has(prop.zpid)) {
                    properties.set(prop.zpid, prop);
                    newlyDiscovered.push(prop);
                }
            });
            countBadge.textContent = properties.size;
            updateScanVisibility();

            // Trigger auto-sync in the background if we found new listings
            if (newlyDiscovered.length > 0) {
                autoSyncProperties(newlyDiscovered);
            }
        } else if (type === 'ZILLOW_TOTAL_COUNT') {
            totalResultCount = data.count;
            updateScanVisibility();
        }
    });

    // Scan All Pages functionality
    scanBtn.onclick = () => {
        scanBtn.innerHTML = '<span>Scanning...</span>';
        scanBtn.disabled = true;
        window.postMessage({ type: 'ZILLOW_SCAN_PAGES' }, '*');
        
        const checkDone = setInterval(() => {
            if (properties.size >= totalResultCount) {
                scanBtn.style.display = 'none';
                scanBtn.disabled = false;
                scanBtn.innerHTML = `
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="22" y1="12" x2="18" y2="12"></line><line x1="6" y1="12" x2="2" y2="12"></line><line x1="12" y1="6" x2="12" y2="2"></line><line x1="12" y1="22" x2="12" y2="18"></line></svg>
                    <span>Scan All Pages</span>
                `;
                clearInterval(checkDone);
            }
        }, 2000);
    };

    // CSV Sheets Copy functionality
    exportBtn.onclick = () => {
        if (properties.size === 0) {
            alert('No properties found yet. Try scrolling or moving the map.');
            return;
        }
        const data = Array.from(properties.values());
        const headers = ['ZPID', 'Link', 'Address', 'Price', 'Zestimate', 'Tax Assessed Value'];
        const csvRows = [
            headers.join('\t'),
            ...data.map(p => [
                p.zpid, p.url, (p.address || '').replace(/[\t\n\r]/g, ' '),
                p.price || '', p.zestimate || '', p.taxAssessedValue || ''
            ].join('\t'))
        ];
        const csvContent = csvRows.join('\n');
        navigator.clipboard.writeText(csvContent).then(() => {
            const originalHTML = exportBtn.innerHTML;
            exportBtn.innerHTML = '<span>✅ Copied for Sheets!</span>';
            setTimeout(() => { exportBtn.innerHTML = originalHTML; countBadge.textContent = properties.size; }, 2000);
        }).catch(() => {
            const blob = new Blob([csvContent.replace(/\t/g, ',')], { type: 'text/csv' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = `zillow_export_${new Date().toISOString().split('T')[0]}.csv`; a.click();
        });
    };

    // Settings overlay modal implementation
    syncBadge.onclick = () => {
        // Prevent duplicate modals
        if (document.getElementById('zillow-vault-settings-modal')) return;

        const overlay = document.createElement('div');
        overlay.className = 'zillow-settings-overlay';
        overlay.id = 'zillow-vault-settings-modal-overlay';

        const modal = document.createElement('div');
        modal.className = 'zillow-settings-modal';
        modal.id = 'zillow-vault-settings-modal';

        modal.innerHTML = `
            <div class="zillow-settings-title">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                <span>Zillow Data Vault Settings</span>
            </div>
            <div class="zillow-settings-desc">
                Enable real-time synchronization. Paste the companion site's API Endpoint URL (e.g. <code>http://localhost:8788</code> for local, or your custom Cloudflare pages domain).
            </div>
            <label class="zillow-settings-label">Vault API Endpoint URL</label>
            <input type="text" id="zillow-settings-url-input" class="zillow-settings-input" placeholder="http://localhost:8788" value="${vaultUrl}">
            <div class="zillow-settings-actions">
                <button id="zillow-settings-btn-cancel" class="zillow-settings-btn cancel">Cancel</button>
                <button id="zillow-settings-btn-save" class="zillow-settings-btn save">Save Connection</button>
            </div>
        `;

        document.body.appendChild(overlay);
        document.body.appendChild(modal);

        const close = () => {
            overlay.remove();
            modal.remove();
        };

        overlay.onclick = close;
        document.getElementById('zillow-settings-btn-cancel').onclick = close;

        document.getElementById('zillow-settings-btn-save').onclick = async () => {
            const inputVal = document.getElementById('zillow-settings-url-input').value.trim();
            // Remove trailing slashes
            let cleanUrl = inputVal.replace(/\/+$/, "");

            if (cleanUrl) {
                // If they pasted the full endpoint path, automatically strip the /api/listings suffix
                cleanUrl = cleanUrl.replace(/\/api\/listings\/?$/i, "");

                // If protocol is missing, automatically prepend
                if (!/^https?:\/\//i.test(cleanUrl)) {
                    if (cleanUrl.includes("localhost") || cleanUrl.includes("127.0.0.1")) {
                        cleanUrl = "http://" + cleanUrl;
                    } else {
                        cleanUrl = "https://" + cleanUrl;
                    }
                }
            }

            if (!cleanUrl) {
                chrome.storage.local.set({ vaultUrl: "" }, () => {
                    vaultUrl = "";
                    updateSyncUI('offline', '🔴 Setup Vault');
                    close();
                });
                return;
            }

            // Perform connection validation!
            updateSyncUI('syncing', '🟡 Connecting...');
            try {
                const response = await fetch(`${cleanUrl}/api/listings`, { method: "GET" });
                if (response.ok) {
                    chrome.storage.local.set({ vaultUrl: cleanUrl }, () => {
                        console.log("[Zillow Export] Saved Vault URL after test success:", cleanUrl);
                        vaultUrl = cleanUrl;
                        updateSyncUI('online', '🟢 Vault Active');
                        // Sync any existing properties immediately to backfill!
                        if (properties.size > 0) {
                            autoSyncProperties(Array.from(properties.values()));
                        }
                        close();
                    });
                } else {
                    updateSyncUI('offline', `🔴 Database Offline (${response.status})`);
                    alert(`⚠️ Connection test failed: Server returned status ${response.status}.\n\nPlease ensure you have linked your D1 database (DB) to your website in the Cloudflare dashboard.`);
                }
            } catch (err) {
                console.error("[Zillow Export] Connection test error:", err);
                updateSyncUI('offline', '🔴 Connection Error');
                alert(`⚠️ Connection test failed! Could not reach "${cleanUrl}".\n\nPlease ensure your website is online and that there are no typos in the URL.`);
            }
        };
    };

    // Safety auto-close fallback for background refreshes
    if (window.location.search.includes('autoSync=true') || window.location.hash.includes('autoSync=true')) {
        setTimeout(() => {
            console.log("[Zillow Export] Auto-Sync tab closing via fallback timeout.");
            window.close();
        }, 8000);
    }
})();
