(function() {
    let lastSearchRequest = null;
    let totalResults = 0;
    const originalFetch = window.fetch;

    function notify(type, data) {
        window.dispatchEvent(new CustomEvent('zillow-data-event', {
            detail: { type, data }
        }));
    }

    function extractHomeInfo(home) {
        if (!home) return null;
        const hdp = home.hdpData?.homeInfo || {};
        const zpid = hdp.zpid || home.zpid;
        if (!zpid) return null;

        const price = hdp.price || home.unformattedPrice || home.price;
        const beds = home.beds || hdp.bedrooms || null;
        const baths = home.baths || hdp.bathrooms || null;
        const sqft = home.area || hdp.livingArea || home.sqft || null;
        const imgSrc = home.imgSrc || hdp.imgSrc || home.imageLink || null;
        
        let pricePerSqft = hdp.pricePerSquareFoot || home.pricePerSqft || null;
        if (!pricePerSqft && price && sqft) {
            const numPrice = typeof price === 'number' ? price : parseFloat(String(price).replace(/[^0-9.]/g, ''));
            const numSqft = typeof sqft === 'number' ? sqft : parseFloat(String(sqft).replace(/[^0-9.]/g, ''));
            if (numPrice && numSqft && numSqft > 0) {
                pricePerSqft = Math.round(numPrice / numSqft);
            }
        }

        return {
            zpid: zpid,
            url: home.detailUrl || hdp.detailUrl || `https://www.zillow.com/homedetails/${zpid}_zpid/`,
            price: price,
            zestimate: hdp.zestimate || home.zestimate,
            taxAssessedValue: hdp.taxAssessedValue,
            address: hdp.address || home.address || (hdp.streetAddress ? (hdp.streetAddress + ', ' + hdp.city + ', ' + hdp.state + ' ' + hdp.zipcode) : null),
            beds: beds,
            baths: baths,
            sqft: sqft,
            pricePerSqft: pricePerSqft,
            imgSrc: imgSrc
        };
    }

    function processResults(results) {
        if (!results) return;
        const properties = [];
        const items = results.listResults || results.mapResults || [];
        if (Array.isArray(items)) {
            items.forEach(home => {
                const data = extractHomeInfo(home);
                if (data && data.zpid) properties.push(data);
            });
        }

        if (properties.length > 0) {
            notify('ZILLOW_DATA_FOUND', { properties });
        }
    }

    window.fetch = function(...args) {
        const requestArg = args[0];
        const options = args[1] || {};
        const responsePromise = originalFetch.apply(window, args);

        (async () => {
            try {
                const response = await responsePromise;
                if (!response.ok) return;

                let urlStr = '';
                if (typeof requestArg === 'string') urlStr = requestArg;
                else if (requestArg instanceof Request) urlStr = requestArg.url;
                else if (requestArg instanceof URL) urlStr = requestArg.href;

                if (urlStr.includes('/graphql') || urlStr.includes('/search-page-state') || urlStr.includes('/GetSearchPageState')) {
                    let requestBody = options.body;
                    if (requestBody && typeof requestBody === 'string') {
                        try {
                            const body = JSON.parse(requestBody);
                            if (body.variables?.searchQueryState || body.operationName?.includes('Search')) {
                                lastSearchRequest = {
                                    url: urlStr,
                                    headers: options.headers || {},
                                    bodyTemplate: body
                                };
                            }
                        } catch(e) {}
                    }

                    const clone = response.clone();
                    const data = await clone.json();
                    
                    const findResults = (obj) => {
                        if (!obj || typeof obj !== 'object') return;
                        if (obj.totalResultCount !== undefined) {
                            totalResults = obj.totalResultCount;
                            notify('ZILLOW_TOTAL_COUNT', { count: totalResults });
                        }
                        if (obj.listResults || obj.mapResults) {
                            processResults(obj);
                            return;
                        }
                        for (const key in obj) findResults(obj[key]);
                    };
                    findResults(data);
                }
            } catch (e) {}
        })();

        return responsePromise;
    };

    function checkNextData() {
        const pageProps = window.__NEXT_DATA__?.props?.pageProps;
        if (!pageProps) return;

        const findResults = (obj) => {
            if (!obj || typeof obj !== 'object') return;
            if (obj.totalResultCount !== undefined) {
                totalResults = obj.totalResultCount;
                notify('ZILLOW_TOTAL_COUNT', { count: totalResults });
            }
            if (obj.listResults || obj.mapResults) {
                processResults(obj);
                // Don't return, keep searching for total count
            }
            for (const key in obj) {
                // Avoid recursion into very deep or cyclical objects if necessary, but Zillow's NEXT_DATA is usually safe
                if (key !== 'parent' && obj.hasOwnProperty(key)) {
                    findResults(obj[key]);
                }
            }
        };

        findResults(pageProps);
    }

    window.addEventListener('message', async (event) => {
        if (event.data.type === 'ZILLOW_SCAN_PAGES' && lastSearchRequest) {
            const startPage = 2;
            const maxPages = Math.ceil(totalResults / 40);
            for (let p = startPage; p <= maxPages; p++) {
                const body = JSON.parse(JSON.stringify(lastSearchRequest.bodyTemplate));
                if (body.variables.searchQueryState) {
                    body.variables.searchQueryState.pagination = { currentPage: p };
                }
                try {
                    const res = await originalFetch(lastSearchRequest.url, {
                        method: 'POST',
                        headers: lastSearchRequest.headers,
                        body: JSON.stringify(body)
                    });
                    processResults(await res.json());
                    // 10 second delay for maximum safety
                    await new Promise(r => setTimeout(r, 10000));
                } catch(e) {}
            }
        }
    });

    // Initial and periodic checks
    setTimeout(checkNextData, 2000);
    setInterval(checkNextData, 5000);
})();
